import React from 'react'

function Root() {
  return <div>
    <h1>Petful</h1>
  </div>
}

export default Root
